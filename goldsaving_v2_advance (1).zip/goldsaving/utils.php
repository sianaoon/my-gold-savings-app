<?php
require_once __DIR__.'/config.php';
function get_latest_rate() {
  $pdo = db();
  $stmt = $pdo->query("SELECT * FROM gold_rates ORDER BY rate_date DESC, id DESC LIMIT 1");
  return $stmt->fetch();
}
function user_balance_gram($user_id) {
  $pdo = db();
  $stmt = $pdo->prepare("SELECT COALESCE(SUM(CASE WHEN txn_type='deposit' THEN gold_gram ELSE 0 END),0) - COALESCE(SUM(CASE WHEN txn_type='withdraw' THEN gold_gram ELSE 0 END),0) AS bal FROM gold_transactions WHERE user_id=?");
  $stmt->execute([$user_id]);
  $row = $stmt->fetch();
  return (float)($row['bal'] ?? 0);
}
function transactions_for_user($user_id, $limit=50) {
  $pdo = db();
  $stmt = $pdo->prepare("SELECT * FROM gold_transactions WHERE user_id=? ORDER BY id DESC LIMIT ?");
  $stmt->bindValue(1, $user_id, PDO::PARAM_INT);
  $stmt->bindValue(2, $limit, PDO::PARAM_INT);
  $stmt->execute();
  return $stmt->fetchAll();
}
function setting_get($name, $default=null) {
  $pdo = db();
  try {
    $st = $pdo->prepare("SELECT value FROM system_settings WHERE name=? LIMIT 1");
    $st->execute([$name]);
    $v = $st->fetchColumn();
    return $v !== false ? $v : $default;
  } catch (Exception $e) {
    return $default;
  }
}
function setting_set($name, $value) {
  $pdo = db();
  $st = $pdo->prepare("INSERT INTO system_settings(name, value) VALUES(?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)");
  $st->execute([$name, $value]);
}
?>