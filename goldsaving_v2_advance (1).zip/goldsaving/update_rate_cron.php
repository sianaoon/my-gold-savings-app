<?php
require_once __DIR__.'/utils.php';
$pdo = db();
$url = setting_get('gold_api_url', 'https://api.chnwt.dev/thai-gold-api/latest');
$json = @file_get_contents($url);
if (!$json) { error_log('[GoldSaving Cron] Cannot fetch API from: '.$url); exit; }
$data = json_decode($json, true);
if (!$data) { error_log('[GoldSaving Cron] Invalid JSON structure'); exit; }
$buy = $data['buy'] ?? ($data['price']['buy'] ?? null);
$sell = $data['sell'] ?? ($data['price']['sell'] ?? null);
$date = substr(($data['date'] ?? $data['updated'] ?? date('Y-m-d')), 0, 10);
if ($buy && $sell) {
  $st = $pdo->prepare("INSERT INTO gold_rates(rate_date,price_buy,price_sell) VALUES(?,?,?)");
  $st->execute([$date, (float)$buy, (float)$sell]);
  echo "[GoldSaving Cron] Updated rate for {$date}: buy={$buy}, sell={$sell}\n";
} else { error_log('[GoldSaving Cron] Missing buy/sell fields'); }
