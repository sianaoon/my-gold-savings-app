<?php
require_once __DIR__.'/utils.php'; require_login(); if (!is_admin()) { http_response_code(403); exit('Forbidden'); }
$pdo = db(); $type = $_GET['type'] ?? 'transactions'; $fmt = $_GET['fmt'] ?? 'csv';
if ($type === 'transactions') {
  $rows = $pdo->query("SELECT t.created_at, u.fullname, t.txn_type, t.amount_baht, t.gold_gram, t.note FROM gold_transactions t JOIN users u ON u.id=t.user_id ORDER BY t.id DESC LIMIT 100")->fetchAll();
  if ($fmt === 'csv') {
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename=goldsaving_transactions.csv');
    $out = fopen('php://output', 'w'); fputcsv($out, ['created_at','fullname','type','amount_baht','gold_gram','note']);
    foreach ($rows as $r) { fputcsv($out, [$r['created_at'],$r['fullname'],$r['txn_type'],$r['amount_baht'],$r['gold_gram'],$r['note']]); }
    fclose($out); exit;
  } else {
    echo "<h3>GoldSaving — รายงานรายการล่าสุด</h3><table border='1' cellpadding='6'><tr><th>วันที่</th><th>ชื่อ</th><th>ประเภท</th><th>จำนวนเงิน</th><th>ทอง (g)</th><th>หมายเหตุ</th></tr>";
    foreach ($rows as $r) { echo "<tr><td>".htmlspecialchars($r['created_at'])."</td><td>".htmlspecialchars($r['fullname'])."</td><td>".htmlspecialchars($r['txn_type'])."</td><td>".number_format($r['amount_baht'],2)."</td><td>".number_format($r['gold_gram'],4)."</td><td>".htmlspecialchars($r['note'])."</td></tr>"; }
    echo "</table>"; exit;
  }
}
http_response_code(400); echo "Unknown export type";
