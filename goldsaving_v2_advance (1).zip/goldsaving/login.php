<?php
require_once __DIR__.'/config.php';
$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_check($_POST['csrf'] ?? '')) { $error = 'Invalid CSRF token'; }
  else {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($login && $password) {
      $pdo = db();
      $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR phone = ? LIMIT 1");
      $stmt->execute([$login, $login]);
      $user = $stmt->fetch();
      if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = $user;
        header('Location: index.php'); exit;
      } else { $error = 'บัญชีหรือรหัสผ่านไม่ถูกต้อง'; }
    } else { $error = 'กรอกข้อมูลให้ครบถ้วน'; }
  }
}
?>
<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>เข้าสู่ระบบ | GoldSaving</title><script src="https://cdn.tailwindcss.com"></script></head>
<body class="min-h-screen bg-neutral-950 text-neutral-100"><div class="max-w-md mx-auto pt-20 p-6">
<div class="text-center mb-8"><h1 class="text-3xl font-bold">💎 GoldSaving</h1><p class="text-neutral-400">ออมทองง่าย ๆ สไตล์ดำทอง</p></div>
<?php if ($error): ?><div class="mb-4 p-3 rounded bg-red-900/40 border border-red-600 text-red-200"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post" class="space-y-4 bg-neutral-900 p-6 rounded-xl border border-neutral-800">
<input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
<label class="block text-sm">อีเมล หรือ เบอร์โทร
<input name="login" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3" placeholder="you@example.com หรือ 08x-xxx-xxxx"></label>
<label class="block text-sm">รหัสผ่าน
<input name="password" type="password" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3"></label>
<button class="w-full py-3 rounded-lg bg-yellow-500 hover:bg-yellow-400 text-black font-semibold transition">เข้าสู่ระบบ</button>
<p class="text-center text-sm text-neutral-400">ยังไม่มีบัญชี? <a href="register.php" class="text-yellow-400 hover:underline">สมัครสมาชิก</a></p>
</form></div></body></html>
