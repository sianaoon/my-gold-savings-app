<?php
require_once __DIR__.'/utils.php'; require_login(); if (!is_admin()) { http_response_code(403); echo "Forbidden"; exit; }
$pdo = db(); $flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_check($_POST['csrf'] ?? '')) { $_SESSION['flash']=['type'=>'error','msg'=>'Invalid CSRF token']; header('Location: admin_advance.php'); exit; }
  $action = $_POST['action'] ?? '';
  if ($action === 'save_api_url') {
    $url = trim($_POST['api_url'] ?? '');
    if (!filter_var($url, FILTER_VALIDATE_URL)) $_SESSION['flash']=['type'=>'error','msg'=>'URL ไม่ถูกต้อง'];
    else { setting_set('gold_api_url', $url); $_SESSION['flash']=['type'=>'ok','msg'=>'บันทึก API URL เรียบร้อย']; }
    header('Location: admin_advance.php'); exit;
  }
  if ($action === 'fetch_now') {
    $url = setting_get('gold_api_url', 'https://api.chnwt.dev/thai-gold-api/latest');
    $json = @file_get_contents($url);
    if (!$json) { $_SESSION['flash']=['type'=>'error','msg'=>'เชื่อมต่อ API ไม่ได้']; header('Location: admin_advance.php'); exit; }
    $data = json_decode($json, true);
    if (!$data) { $_SESSION['flash']=['type'=>'error','msg'=>'รูปแบบข้อมูลไม่ถูกต้อง']; header('Location: admin_advance.php'); exit; }
    $buy = $data['buy'] ?? ($data['price']['buy'] ?? null);
    $sell = $data['sell'] ?? ($data['price']['sell'] ?? null);
    $date = substr(($data['date'] ?? $data['updated'] ?? date('Y-m-d')), 0, 10);
    if ($buy && $sell) { $st=$pdo->prepare("INSERT INTO gold_rates(rate_date,price_buy,price_sell) VALUES(?,?,?)"); $st->execute([$date,(float)$buy,(float)$sell]); $_SESSION['flash']=['type'=>'ok','msg'=>'อัปเดตราคาทองเรียบร้อย']; }
    else { $_SESSION['flash']=['type'=>'error','msg'=>'ไม่พบฟิลด์ buy/sell ในข้อมูล API']; }
    header('Location: admin_advance.php'); exit;
  }
  if ($action === 'set_manual_price') {
    $buy=(float)($_POST['price_buy']??0); $sell=(float)($_POST['price_sell']??0); $date=$_POST['rate_date']??date('Y-m-d');
    if ($buy>0&&$sell>0) { $st=$pdo->prepare("INSERT INTO gold_rates(rate_date,price_buy,price_sell) VALUES(?,?,?)"); $st->execute([$date,$buy,$sell]); $_SESSION['flash']=['type'=>'ok','msg'=>'บันทึกราคาทอง (ตั้งค่ามือ) สำเร็จ']; }
    else { $_SESSION['flash']=['type'=>'error','msg'=>'กรอกราคาให้ถูกต้อง']; }
    header('Location: admin_advance.php'); exit;
  }
  if ($action === 'toggle_admin') {
    $uid=(int)($_POST['user_id']??0); $val=(int)($_POST['to']??0);
    $st=$pdo->prepare("UPDATE users SET is_admin=? WHERE id=?"); $st->execute([$val,$uid]);
    $_SESSION['flash']=['type'=>'ok','msg'=>'อัปเดตสิทธิ์ผู้ใช้เรียบร้อย']; header('Location: admin_advance.php'); exit;
  }
  if ($action === 'delete_user') {
    $uid=(int)($_POST['user_id']??0);
    if ($uid === (int)current_user()['id']) $_SESSION['flash']=['type'=>'error','msg'=>'ลบตัวเองไม่ได้'];
    else { $st=$pdo->prepare("DELETE FROM users WHERE id=?"); $st->execute([$uid]); $_SESSION['flash']=['type'=>'ok','msg'=>'ลบผู้ใช้เรียบร้อย']; }
    header('Location: admin_advance.php'); exit;
  }
}
$api_url = setting_get('gold_api_url', 'https://api.chnwt.dev/thai-gold-api/latest');
$rates7 = $pdo->query("SELECT rate_date, price_buy, price_sell FROM gold_rates WHERE rate_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) ORDER BY rate_date ASC")->fetchAll();
$users = $pdo->query("SELECT id, fullname, email, phone, is_admin FROM users ORDER BY id DESC")->fetchAll();
$latest_txn = $pdo->query("SELECT t.*, u.fullname FROM gold_transactions t JOIN users u ON u.id=t.user_id ORDER BY t.id DESC LIMIT 10")->fetchAll();
$sum_stmt = $pdo->query("SELECT u.id, u.fullname, COALESCE(SUM(CASE WHEN t.txn_type='deposit' THEN t.gold_gram ELSE 0 END),0) - COALESCE(SUM(CASE WHEN t.txn_type='withdraw' THEN t.gold_gram ELSE 0 END),0) AS gold_gram FROM users u LEFT JOIN gold_transactions t ON t.user_id=u.id GROUP BY u.id, u.fullname ORDER BY gold_gram DESC");
$sums = $sum_stmt->fetchAll();
?>
<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Admin Advance | GoldSaving</title>
<script src="https://cdn.tailwindcss.com"></script><script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/2.0.8/css/dataTables.dataTables.min.css">
<script src="https://cdn.datatables.net/2.0.8/js/dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
</head>
<body class="bg-neutral-950 text-neutral-100 min-h-screen">
<header class="border-b border-neutral-800"><div class="max-w-7xl mx-auto p-4 flex items-center justify-between">
<div class="flex items-center gap-3"><div class="h-9 w-9 rounded-lg bg-yellow-500 text-black font-bold flex items-center justify-center">G</div><div class="font-semibold">GoldSaving — Admin Advance</div></div>
<nav class="text-sm flex gap-4"><a href="index.php" class="hover:text-yellow-400">กลับแดชบอร์ด</a><a href="logout.php" class="hover:text-yellow-400">ออกจากระบบ</a></nav></div></header>
<main class="max-w-7xl mx-auto p-4 space-y-6">
<?php if ($flash): ?><div class="p-3 rounded <?= $flash['type']==='ok' ? 'bg-emerald-900/30 border border-emerald-600 text-emerald-200' : 'bg-red-900/30 border border-red-600 text-red-200' ?>"><?= htmlspecialchars($flash['msg']) ?></div><?php endif; ?>
<section class="grid lg:grid-cols-3 gap-4">
<div class="bg-neutral-900 border border-neutral-800 rounded-xl p-4 space-y-3 lg:col-span-2">
<h2 class="font-semibold text-lg">ตั้งค่า API ราคาทอง</h2>
<form method="post" class="flex flex-col md:flex-row gap-3">
<input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>"><input type="hidden" name="action" value="save_api_url">
<input name="api_url" value="<?= htmlspecialchars($api_url) ?>" class="flex-1 bg-neutral-800 border border-neutral-700 rounded-lg p-3" placeholder="https://api.chnwt.dev/thai-gold-api/latest">
<button class="px-4 py-2 rounded-lg bg-yellow-500 text-black font-semibold hover:bg-yellow-400">บันทึก URL</button></form>
<form method="post" class="flex gap-3"><input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>"><input type="hidden" name="action" value="fetch_now">
<button class="px-4 py-2 rounded-lg bg-emerald-500 text-black font-semibold hover:bg-emerald-400">อัปเดตราคาทันที</button></form>
<div class="text-xs text-neutral-400">ระบบจะพยายาม map ฟิลด์ buy/sell/date อัตโนมัติ</div></div>
<div class="bg-neutral-900 border border-neutral-800 rounded-xl p-4 space-y-3"><h2 class="font-semibold text-lg">ตั้งราคาทอง (มือ)</h2>
<form method="post" class="space-y-2"><input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>"><input type="hidden" name="action" value="set_manual_price">
<label class="block text-sm">วันที่<input type="date" name="rate_date" value="<?= date('Y-m-d') ?>" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-2"></label>
<label class="block text-sm">ซื้อเข้า (฿/g)<input type="number" step="0.01" name="price_buy" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-2"></label>
<label class="block text-sm">ขายออก (฿/g)<input type="number" step="0.01" name="price_sell" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-2"></label>
<button class="w-full py-2 rounded-lg bg-yellow-500 text-black font-semibold hover:bg-yellow-400">บันทึก</button></form></div></section>
<section class="bg-neutral-900 border border-neutral-800 rounded-xl p-4"><h2 class="font-semibold text-lg mb-3">กราฟราคาทองย้อนหลัง 7 วัน</h2>
<canvas id="goldChart" height="100"></canvas>
<script>const rateData = <?= json_encode($rates7) ?>; const labels = rateData.map(r=>r.rate_date); const buy = rateData.map(r=>parseFloat(r.price_buy)); const sell = rateData.map(r=>parseFloat(r.price_sell));
new Chart(document.getElementById('goldChart'), {type:'line', data:{labels, datasets:[{label:'ซื้อเข้า', data:buy},{label:'ขายออก', data:sell}]}, options:{responsive:true, scales:{y:{beginAtZero:false}}}});</script></section>
<section class="bg-neutral-900 border border-neutral-800 rounded-xl p-4"><h2 class="font-semibold text-lg mb-3">ผู้ใช้ & สิทธิ์</h2>
<div class="overflow-x-auto"><table id="tblUsers" class="display text-sm w-full"><thead><tr><th>ID</th><th>ชื่อ</th><th>อีเมล</th><th>โทร</th><th>สิทธิ์</th><th>จัดการ</th></tr></thead><tbody>
<?php foreach ($users as $u): ?><tr>
<td><?= (int)$u['id'] ?></td><td><?= htmlspecialchars($u['fullname']) ?></td><td><?= htmlspecialchars($u['email']) ?></td><td><?= htmlspecialchars($u['phone']) ?></td><td><?= $u['is_admin'] ? 'แอดมิน' : 'ผู้ใช้' ?></td>
<td class="space-x-2">
<form method="post" style="display:inline"><input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>"><input type="hidden" name="action" value="toggle_admin"><input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>"><input type="hidden" name="to" value="<?= $u['is_admin'] ? 0 : 1 ?>"><button class="px-2 py-1 rounded bg-yellow-500 text-black text-xs"><?= $u['is_admin'] ? 'ถอนแอดมิน' : 'ตั้งเป็นแอดมิน' ?></button></form>
<form method="post" style="display:inline" onsubmit="return confirm('ยืนยันลบผู้ใช้คนนี้?')"><input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>"><input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>"><button class="px-2 py-1 rounded bg-red-600 text-white text-xs">ลบ</button></form>
</td></tr><?php endforeach; ?></tbody></table></div><script>new DataTable('#tblUsers');</script></section>
<section class="bg-neutral-900 border border-neutral-800 rounded-xl p-4"><h2 class="font-semibold text-lg mb-3">สรุปยอดทองสะสมต่อผู้ใช้ (กรัม)</h2>
<div class="overflow-x-auto"><table class="min-w-full text-sm"><thead><tr class="text-left border-b border-neutral-800"><th class="p-2">ผู้ใช้</th><th class="p-2">กรัมทอง</th></tr></thead><tbody>
<?php foreach ($sums as $s): ?><tr class="border-b border-neutral-800"><td class="p-2"><?= htmlspecialchars($s['fullname']) ?></td><td class="p-2"><?= number_format($s['gold_ram']??$s['gold_gram'],4) ?></td></tr><?php endforeach; ?></tbody></table></div></section>
<section class="bg-neutral-900 border border-neutral-800 rounded-xl p-4"><div class="flex items-center justify-between mb-3"><h2 class="font-semibold text-lg">รายการล่าสุด</h2>
<div class="flex gap-2"><a class="px-3 py-1.5 rounded bg-neutral-800 border border-neutral-700 text-sm" href="export_report.php?type=transactions&fmt=csv">Export CSV</a>
<button class="px-3 py-1.5 rounded bg-neutral-800 border border-neutral-700 text-sm" onclick="exportPDF()">Export PDF</button></div></div>
<div class="overflow-x-auto"><table class="min-w-full text-sm" id="txnTable"><thead class="text-neutral-400"><tr class="text-left border-b border-neutral-800"><th class="p-2">วันที่</th><th class="p-2">ผู้ใช้</th><th class="p-2">ประเภท</th><th class="p-2">จำนวนเงิน (฿)</th><th class="p-2">ทอง (g)</th><th class="p-2">หมายเหตุ</th></tr></thead><tbody>
<?php foreach ($latest_txn as $t): ?><tr class="border-b border-neutral-800"><td class="p-2"><?= htmlspecialchars($t['created_at']) ?></td><td class="p-2"><?= htmlspecialchars($t['fullname']) ?></td><td class="p-2"><?= $t['txn_type']==='deposit' ? 'ฝาก' : 'ถอน' ?></td><td class="p-2"><?= number_format($t['amount_baht'],2) ?></td><td class="p-2"><?= number_format($t['gold_gram'],4) ?></td><td class="p-2"><?= htmlspecialchars($t['note'] ?? '') ?></td></tr><?php endforeach; ?></tbody></table></div></section>
</main>
<script>
async function exportPDF(){ const { jsPDF } = window.jspdf; const doc = new jsPDF(); doc.setFontSize(14); doc.text('รายงานรายการล่าสุด GoldSaving', 14, 16);
const rows=[]; document.querySelectorAll('#txnTable tbody tr').forEach(tr=>{const cols=[...tr.querySelectorAll('td')].map(td=>td.textContent.trim()); rows.push(cols);});
let y=26; rows.forEach(r=>{ doc.text(r.join('  |  '), 14, y); y+=8; if (y>280){ doc.addPage(); y=16; } }); doc.save('goldsaving_txn_report.pdf'); }
</script>
</body></html>
