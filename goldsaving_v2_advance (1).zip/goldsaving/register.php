<?php
require_once __DIR__.'/config.php';
$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_check($_POST['csrf'] ?? '')) { $error = 'Invalid CSRF token'; }
  else {
    $fullname = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';
    if (!$fullname || !$password || !$password2) $error = 'กรอกข้อมูลให้ครบถ้วน';
    elseif ($password !== $password2) $error = 'รหัสผ่านไม่ตรงกัน';
    else {
      try {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $pdo = db();
        $stmt = $pdo->prepare("INSERT INTO users(fullname,email,phone,password,is_admin) VALUES(?,?,?,?,0)");
        $stmt->execute([$fullname, $email ?: null, $phone ?: null, $hash]);
        $id = $pdo->lastInsertId();
        $st = $pdo->prepare("SELECT * FROM users WHERE id=?"); $st->execute([$id]);
        $_SESSION['user'] = $st->fetch();
        header('Location: index.php'); exit;
      } catch (Exception $e) { $error = 'สมัครสมาชิกไม่สำเร็จ: ' . $e->getMessage(); }
    }
  }
}
?>
<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>สมัครสมาชิก | GoldSaving</title><script src="https://cdn.tailwindcss.com"></script></head>
<body class="min-h-screen bg-neutral-950 text-neutral-100"><div class="max-w-md mx-auto pt-16 p-6">
<h1 class="text-2xl font-bold mb-6">สมัครสมาชิก</h1>
<?php if ($error): ?><div class="mb-4 p-3 rounded bg-red-900/40 border border-red-600 text-red-200"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post" class="space-y-4 bg-neutral-900 p-6 rounded-xl border border-neutral-800">
<input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
<label class="block text-sm">ชื่อ-นามสกุล
<input name="fullname" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3"></label>
<label class="block text-sm">อีเมล (ไม่บังคับ)
<input name="email" type="email" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3"></label>
<label class="block text-sm">เบอร์โทร (ไม่บังคับ)
<input name="phone" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3"></label>
<div class="grid grid-cols-2 gap-3">
<label class="block text-sm">รหัสผ่าน
<input name="password" type="password" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3"></label>
<label class="block text-sm">ยืนยันรหัส
<input name="password2" type="password" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3"></label>
</div>
<button class="w-full py-3 rounded-lg bg-yellow-500 hover:bg-yellow-400 text-black font-semibold transition">สมัครสมาชิก</button>
<p class="text-center text-sm text-neutral-400">มีบัญชีแล้ว? <a href="login.php" class="text-yellow-400 hover:underline">เข้าสู่ระบบ</a></p>
</form></div></body></html>
