<?php
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'goldsaving');
define('DB_USER', getenv('DB_USER') ?: 'goldsaving_user');
define('DB_PASS', getenv('DB_PASS') ?: 'change_this_password');
define('APP_NAME', 'GoldSaving');
define('APP_THEME', 'black-gold');
session_start();
function db() {
  static $pdo;
  if ($pdo) return $pdo;
  $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4';
  try {
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
  } catch (Exception $e) { http_response_code(500); echo 'Database connection failed: ' . htmlspecialchars($e->getMessage()); exit; }
  return $pdo;
}
function csrf_token() { if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(32)); } return $_SESSION['csrf']; }
function csrf_check($t) { return isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $t ?? ''); }
function current_user(){ return $_SESSION['user'] ?? null; }
function require_login(){ if (!current_user()) { header('Location: login.php'); exit; } }
function is_admin(){ return current_user() && (int)current_user()['is_admin'] === 1; }
?>