<?php
require_once __DIR__.'/utils.php'; require_login(); if (!is_admin()) { http_response_code(403); echo "Forbidden"; exit; }
$pdo = db(); $rate = get_latest_rate(); $flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_check($_POST['csrf'] ?? '')) { $_SESSION['flash']=['type'=>'error','msg'=>'Invalid CSRF token']; header('Location: admin.php'); exit; }
  $buy=(float)($_POST['price_buy']??0); $sell=(float)($_POST['price_sell']??0); $date=$_POST['rate_date']??date('Y-m-d');
  if ($buy<=0||$sell<=0){ $_SESSION['flash']=['type'=>'error','msg'=>'กรอกราคาให้ถูกต้อง']; }
  else { $st=$pdo->prepare("INSERT INTO gold_rates(rate_date,price_buy,price_sell) VALUES(?,?,?)"); $st->execute([$date,$buy,$sell]); $_SESSION['flash']=['type'=>'ok','msg'=>'อัปเดตราคาเรียบร้อย']; }
  header('Location: admin.php'); exit;
}
?>
<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>ตั้งค่าราคา | GoldSaving</title><script src="https://cdn.tailwindcss.com"></script></head>
<body class="min-h-screen bg-neutral-950 text-neutral-100"><div class="max-w-3xl mx-auto p-4">
<header class="flex items-center justify-between py-4"><h1 class="text-2xl font-semibold">ตั้งค่าราคาทอง (บาท/กรัม)</h1><a href="index.php" class="text-sm text-yellow-400 hover:underline">กลับแดชบอร์ด</a></header>
<?php if ($flash): ?><div class="mb-4 p-3 rounded <?= $flash['type']==='ok' ? 'bg-emerald-900/30 border border-emerald-600 text-emerald-200' : 'bg-red-900/30 border border-red-600 text-red-200' ?>"><?= htmlspecialchars($flash['msg']) ?></div><?php endif; ?>
<div class="bg-neutral-900 border border-neutral-800 rounded-xl p-4 space-y-3">
<form method="post" class="grid md:grid-cols-3 gap-3">
<input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
<label class="block text-sm">วันที่<input name="rate_date" type="date" value="<?= htmlspecialchars($rate['rate_date'] ?? date('Y-m-d')) ?>" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3"></label>
<label class="block text-sm">ซื้อเข้า (บาท/กรัม)<input name="price_buy" type="number" step="0.01" value="<?= htmlspecialchars($rate['price_buy'] ?? '') ?>" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3"></label>
<label class="block text-sm">ขายออก (บาท/กรัม)<input name="price_sell" type="number" step="0.01" value="<?= htmlspecialchars($rate['price_sell'] ?? '') ?>" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3"></label>
<div class="md:col-span-3"><button class="w-full py-3 rounded-lg bg-yellow-500 hover:bg-yellow-400 text-black font-semibold">บันทึก</button></div>
</form></div></div></body></html>
