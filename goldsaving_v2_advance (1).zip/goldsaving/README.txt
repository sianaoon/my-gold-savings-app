
GoldSaving v2 — Admin Advance Edition (PHP + MySQL)

NEW in v2:
- admin_advance.php (ตั้งค่า API ราคาทอง, อัปเดตอัตโนมัติ, กราฟ 7 วัน, จัดการผู้ใช้, Export CSV/PDF)
- update_rate_cron.php (ใช้กับ cron อัปเดตราคาอัตโนมัติ)
- export_report.php (export CSV/PDF)
- index.php เพิ่มปุ่ม "Admin Advance" (เฉพาะแอดมิน)

1) Database
   - Import init.sql
   - Create DB user (example):
     CREATE USER 'goldsaving_user'@'localhost' IDENTIFIED BY 'change_this_password';
     GRANT ALL PRIVILEGES ON goldsaving.* TO 'goldsaving_user'@'localhost';
     FLUSH PRIVILEGES;

2) Config
   - Edit config.php or set ENV: DB_HOST, DB_NAME, DB_USER, DB_PASS

3) First Use
   - Register new account via register.php
   - Make admin:
     UPDATE users SET is_admin=1 WHERE email='you@example.com' OR phone='08...';
   - Open admin_advance.php -> set API URL (default already set)

4) Cron
   - Example (run daily 09:00):
     0 9 * * * /usr/bin/php /var/www/html/goldsaving/update_rate_cron.php

5) Export
   - CSV: admin_advance -> Export CSV (or export_report.php?type=transactions&fmt=csv)
   - PDF: Click Export PDF (client-side jsPDF), or open export_report.php?type=transactions&fmt=pdf then Save as PDF

Security (Prototype):
   - CSRF tokens, password_hash, prepared statements.
   - For production: HTTPS, role-based policies, audit logs, payment flows.
