<?php
require_once __DIR__.'/utils.php';
require_login();
$pdo = db();
$rate = get_latest_rate();
$bal_gram = user_balance_gram(current_user()['id']);
$bal_baht = $rate ? $bal_gram * (float)$rate['price_sell'] : 0;
$txns = transactions_for_user(current_user()['id'], 100);
$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_check($_POST['csrf'] ?? '')) { $_SESSION['flash']=['type'=>'error','msg'=>'Invalid CSRF token']; header('Location: index.php'); exit; }
  $action = $_POST['action'] ?? '';
  if ($action === 'deposit') {
    $amount = (float)($_POST['amount_baht'] ?? 0); $note = trim($_POST['note'] ?? '');
    if ($amount <= 0) $_SESSION['flash']=['type'=>'error','msg'=>'จำนวนเงินไม่ถูกต้อง'];
    elseif (!$rate) $_SESSION['flash']=['type'=>'error','msg'=>'ยังไม่ตั้งราคาทอง'];
    else { $gold_gram = $amount / (float)$rate['price_buy']; $st=$pdo->prepare("INSERT INTO gold_transactions(user_id,txn_type,amount_baht,gold_gram,note) VALUES(?,?,?,?,?)"); $st->execute([current_user()['id'],'deposit',$amount,$gold_gram,$note?:'']); $_SESSION['flash']=['type'=>'ok','msg'=>'บันทึกออมทองเรียบร้อย']; }
    header('Location: index.php'); exit;
  }
  if ($action === 'withdraw') {
    $gram = (float)($_POST['gold_gram'] ?? 0); $note = trim($_POST['note'] ?? '');
    if ($gram <= 0) $_SESSION['flash']=['type'=>'error','msg'=>'จำนวนกรัมไม่ถูกต้อง'];
    elseif ($gram > user_balance_gram(current_user()['id'])) $_SESSION['flash']=['type'=>'error','msg'=>'กรัมทองไม่พอ'];
    else { $amount_baht = $rate ? $gram * (float)$rate['price_sell'] : 0; $st=$pdo->prepare("INSERT INTO gold_transactions(user_id,txn_type,amount_baht,gold_gram,note) VALUES(?,?,?,?,?)"); $st->execute([current_user()['id'],'withdraw',$amount_baht,$gram,$note?:'']); $_SESSION['flash']=['type'=>'ok','msg'=>'บันทึกถอนทองเรียบร้อย']; }
    header('Location: index.php'); exit;
  }
}
?>
<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>แดชบอร์ด | GoldSaving</title><script src="https://cdn.tailwindcss.com"></script></head>
<body class="min-h-screen bg-neutral-950 text-neutral-100">
<header class="border-b border-neutral-800"><div class="max-w-6xl mx-auto p-4 flex items-center justify-between">
<div class="flex items-center gap-3"><div class="h-9 w-9 rounded-lg bg-yellow-500 flex items-center justify-center text-black font-bold">G</div>
<div><div class="font-bold">GoldSaving</div><div class="text-xs text-neutral-400"><?= htmlspecialchars(current_user()['fullname']) ?></div></div></div>
<nav class="flex items-center gap-4 text-sm">
<?php if (is_admin()): ?>
<a class="hover:text-yellow-400" href="admin.php">ตั้งค่าราคา (Basic)</a>
<a class="px-3 py-1.5 rounded-lg bg-yellow-500 text-black hover:bg-yellow-400" href="admin_advance.php">Admin Advance</a>
<?php endif; ?>
<a class="hover:text-yellow-400" href="logout.php">ออกจากระบบ</a>
</nav></div></header>
<main class="max-w-6xl mx-auto p-4 space-y-6">
<?php if ($flash): ?><div class="p-3 rounded <?= $flash['type']==='ok' ? 'bg-emerald-900/30 border border-emerald-600 text-emerald-200' : 'bg-red-900/30 border border-red-600 text-red-200' ?>"><?= htmlspecialchars($flash['msg']) ?></div><?php endif; ?>
<section class="grid md:grid-cols-3 gap-4">
<div class="bg-neutral-900 border border-neutral-800 rounded-xl p-4"><div class="text-sm text-neutral-400">ยอดทองสะสม (กรัม)</div><div class="text-3xl font-bold mt-2"><?= number_format($bal_gram,4) ?> g</div></div>
<div class="bg-neutral-900 border border-neutral-800 rounded-xl p-4"><div class="text-sm text-neutral-400">ประมาณมูลค่า (บาท)</div><div class="text-3xl font-bold mt-2"><?= number_format($bal_baht,2) ?> ฿</div></div>
<div class="bg-neutral-900 border border-neutral-800 rounded-xl p-4"><div class="text-sm text-neutral-400">ราคาทอง (บาท/กรัม)</div><div class="mt-2"><?php if ($rate): ?><div class="text-xl">ซื้อเข้า: <span class="font-bold"><?= number_format($rate['price_buy'],2) ?></span></div><div class="text-xl">ขายออก: <span class="font-bold"><?= number_format($rate['price_sell'],2) ?></span></div><div class="text-xs text-neutral-500 mt-1">อัปเดต: <?= htmlspecialchars($rate['rate_date']) ?></div><?php else: ?><div class="text-red-300">ยังไม่ตั้งราคา</div><?php endif; ?></div></div>
</section>
<section class="grid md:grid-cols-2 gap-6">
<form method="post" class="bg-neutral-900 border border-neutral-800 rounded-xl p-4 space-y-3">
<input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>"><input type="hidden" name="action" value="deposit">
<h2 class="font-semibold text-lg">ออมทอง (ใส่จำนวนเงิน)</h2>
<label class="block text-sm">จำนวนเงิน (บาท)
<input name="amount_baht" type="number" step="0.01" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3" placeholder="เช่น 1,000"></label>
<label class="block text-sm">หมายเหตุ (ถ้ามี)
<input name="note" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3" placeholder="โอนผ่านพร้อมเพย์"></label>
<button class="w-full py-3 rounded-lg bg-yellow-500 hover:bg-yellow-400 text-black font-semibold">บันทึกออม</button>
<?php if ($rate): ?><p class="text-xs text-neutral-400">≈ ได้ทอง: <span id="est-gram">0.0000</span> กรัม (อิงราคา <?= number_format($rate['price_buy'],2) ?> ฿/g)</p>
<script>document.addEventListener('input', e => {const input=document.querySelector('input[name="amount_baht"]'); const est=(parseFloat(input.value||0)/<?= (float)$rate['price_buy'] ?>); document.getElementById('est-gram').textContent=isFinite(est)?est.toFixed(4):'0.0000';});</script><?php endif; ?>
</form>
<form method="post" class="bg-neutral-900 border border-neutral-800 rounded-xl p-4 space-y-3">
<input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>"><input type="hidden" name="action" value="withdraw">
<h2 class="font-semibold text-lg">ถอนทอง (ใส่จำนวนกรัม)</h2>
<label class="block text-sm">จำนวนทอง (กรัม)
<input name="gold_gram" type="number" step="0.0001" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3" placeholder="เช่น 0.5"></label>
<label class="block text-sm">หมายเหตุ (ถ้ามี)
<input name="note" class="mt-1 w-full bg-neutral-800 border border-neutral-700 rounded-lg p-3" placeholder="รับเป็นเงิน/รับทองจริง"></label>
<button class="w-full py-3 rounded-lg bg-yellow-500 hover:bg-yellow-400 text-black font-semibold">บันทึกถอน</button>
<?php if ($rate): ?><p class="text-xs text-neutral-400">≈ ได้เงิน: <span id="est-baht">0.00</span> บาท (อิงราคา <?= number_format($rate['price_sell'],2) ?> ฿/g)</p>
<script>document.addEventListener('input', e => {const input=document.querySelector('input[name="gold_gram"]'); const est=(parseFloat(input.value||0)*<?= (float)$rate['price_sell'] ?>); document.getElementById('est-baht').textContent=isFinite(est)?est.toFixed(2):'0.00';});</script><?php endif; ?>
</form></section>
<section class="bg-neutral-900 border border-neutral-800 rounded-xl p-4"><h2 class="font-semibold text-lg mb-3">ประวัติรายการ</h2>
<div class="overflow-x-auto"><table class="min-w-full text-sm"><thead class="text-neutral-400"><tr class="text-left border-b border-neutral-800"><th class="p-2">วันที่</th><th class="p-2">ประเภท</th><th class="p-2">จำนวนเงิน (฿)</th><th class="p-2">ทอง (g)</th><th class="p-2">หมายเหตุ</th></tr></thead>
<tbody>
<?php foreach ($txns as $t): ?><tr class="border-b border-neutral-800">
<td class="p-2"><?= htmlspecialchars($t['created_at']) ?></td>
<td class="p-2"><span class="px-2 py-1 rounded text-xs <?= $t['txn_type']==='deposit' ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-700' : 'bg-red-600/20 text-red-300 border border-red-700' ?>"><?= $t['txn_type']==='deposit' ? 'ฝาก (ออม)' : 'ถอน' ?></span></td>
<td class="p-2"><?= number_format($t['amount_baht'],2) ?></td>
<td class="p-2"><?= number_format($t['gold_gram'],4) ?></td>
<td class="p-2"><?= htmlspecialchars($t['note'] ?? '') ?></td>
</tr><?php endforeach; ?>
</tbody></table></div></section></main></body></html>
